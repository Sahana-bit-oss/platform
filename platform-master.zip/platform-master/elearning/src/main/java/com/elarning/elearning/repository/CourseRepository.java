package com.elarning.elearning.repository;

import com.elarning.elearning.model.Course;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CourseRepository extends JpaRepository<Course,Long>{

}
